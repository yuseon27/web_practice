from django.apps import AppConfig


class SocialloginappConfig(AppConfig):
    name = 'SocialLoginApp'
